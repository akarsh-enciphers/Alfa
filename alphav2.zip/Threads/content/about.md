+++
title = "About Threads"
date = "2020-12-16"
sidemenu = "true"
description = "Developed by Enciphers"
+++

It’s a NodeJs based application and it has also used EJS as a frontend development templating engine with bootstrap and a mix of simple HTML, CSS is used to buit this web application.

This web application comes up with various web application vulnerabilities just like some real web applications have and these vulnerabilities are the challenges on this web application which are need to be solved by its users. So this application act as a vulnerable web lab where users can have hands-on paractice on the different vulnerabilities present in it.  

It also consist of  various features like:

* A user can sign up and login into this application.
* A user can create posts, he/she can also add images to the post he/she creates.
* A user can like and can comment on other users posts.
* A user can also chat witha another user.
* A user can tag as many users he want to tag in his post.

Learn more on [Github](https://github.com/enciphers).

Have questions or suggestions? Feel free to [open an issue on GitHub](https://github.com/enciphers) or [ask me on Twitter](https://twitter.com/enciphers_).

Thanks for reading!
